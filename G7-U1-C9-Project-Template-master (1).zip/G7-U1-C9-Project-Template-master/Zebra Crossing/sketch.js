//Variable named "Stripes" to create a new group
var stripes;

function setup() {
  createCanvas(450, 400);

   //Draw stripes using for loop
}

function draw() {
  background("gray");

  drawSprites();
}
